reservas = [
    [1, 30555999, (2025,8,15), (2025,8,20), 101, 2,  75000],
    [2, 28444888, (2025,8,18), (2025,8,25), 102, 3, 126000],
    [3, 33222111, (2025,9, 1), (2025,9, 5), 103, 2, 72000],
    [4, 29888777, (2025,8,10), (2025,8,15), 104, 4,  106250],
    [5, 31222333, (2025,8,22), (2025,8,24), 105, 1,  22800]
]

habitaciones = [
    [101, 15000, "Doble", 2, "Disponible"],
    [102, 20000, "Triple", 3, "Ocupada"],
    [103, 18000, "Doble", 2, "Mantenimiento"],
    [104, 25000, "Suite", 4, "Disponible"],
    [105, 12000, "Single", 1, "Disponible"]
]

clientes = [
    [30555999, "Juan", "Pérez", "1123456789", "juan.perez@email.com"],
    [28444888, "María", "Gómez", "1167894321", "maria.gomez@email.com"],
    [33222111, "Lucas", "Martínez", "1134567890", "lucas.martinez@email.com"],
    [29888777, "Sofía", "López", "1145678901", "sofia.lopez@email.com"],
    [31222333, "Martín", "Díaz", "1178901234", "martin.diaz@email.com"]
]

